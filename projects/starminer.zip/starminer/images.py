import pygame

LOADED_IMAGES = {}

def get(path):
	if path in LOADED_IMAGES.keys():
		return LOADED_IMAGES[path]
	else:
		LOADED_IMAGES[path] = pygame.image.load(path).convert()
		LOADED_IMAGES[path].set_colorkey((255, 0, 255))
		return LOADED_IMAGES[path]
