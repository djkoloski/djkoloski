import pygame, math
import constants, sprite, transform, font, collision, images, label
from linear import *
from meta import *

ORE_RADIUS = 14
PASSIVE_PRIORITY = 4
NEUTRALIZED_ORE_SPACING = 30.0

STAR_SPEED = 50.0
STAR_SCALE = 1.5
STAR_SCALE_VARIANCE = 0.75
STAR_COLOR_CHANCE = 15
STAR_COLOR_NAMES = ['white', 'yellow', 'orange', 'red', 'blue']

class Passive(PriorityDrawable, GameObject):
	def __init__(self, sprite, speed, name, turn = False, order = PASSIVE_PRIORITY):
		PriorityDrawable.__init__(self, order)
		
		self.sprite = sprite
		self.transform = self.sprite.transform
		self.speed = speed
		self.passiveName = name
		self.turn = turn
	
	def expired(self):
		return not self.transform.pos > constants.OBJECT_BOX[0] or not self.transform.pos < constants.OBJECT_BOX[1]
	
	def update(self, state):
		if self.turn:
			self.transform.rot = state.rotation.rot
		self.transform.move(Vector.fromAM(state.rotation.rot - 90, self.speed * state.keyboard.delta))
		
		self.sprite.update(state)
	
	def draw(self, state):
		self.sprite.draw(state)

class LabeledPassive(Passive):
	def __init__(self, sprite, speed, radius, name, turn = False, order = PASSIVE_PRIORITY):
		Passive.__init__(self, sprite, speed, name, turn, order)
		
		self.label = label.StaticLabel(self.transform, Vector(0.0, radius + 5.0), font.make_epilepsy(18, self.passiveName))
	
	def update(self, state):
		Passive.update(self, state)
		
		self.label.set_string(self.passiveName)
		self.label.update(state)
	
	def draw(self, state):
		Passive.draw(self, state)
		self.label.draw(state)

class Star(Passive):
	def __init__(self, pos, speed, scale):
		rot = 0
		form = transform.Transform(pos, rot, Vector(scale, scale))
		color = 0
		if random.randint(0, STAR_COLOR_CHANCE) == 0:
			color = random.randint(1, 4)
		spr = sprite.Sprite(images.get('media/stars/' + STAR_COLOR_NAMES[color] + '.png'), form)
		Passive.__init__(self, spr, speed, 'STAR')
	
	def expired(self):
		return False
	
	def update(self, state):
		Passive.update(self, state)
		
		self.transform.pos.x %= constants.RESOLUTION.x
		self.transform.pos.y %= constants.RESOLUTION.y

class PassiveFactory(Manager):
	def spawn_neutralized_ore(self, state, pos = None, amount = 1):
		if pos == None:
			Vector(0.0, 0.0)
		
		img = images.get('media/ores/neutralized.png')
		
		r = Vector.fromAM(state.rotation.rot, NEUTRALIZED_ORE_SPACING)
		for n in xrange(amount):
			state.add_object(LabeledPassive(sprite.Sprite(img, transform.Transform(pos + r * (n - amount / 2.0))), 100.0, ORE_RADIUS, 'NEUTRALIZED ORE', True))
	
	def spawn_star(self, state):
		scale = prandom(STAR_SCALE, STAR_SCALE_VARIANCE)
		state.add_object(Star(Vector(random.randint(0, int(constants.RESOLUTION.x) - 1), random.randint(0, int(constants.RESOLUTION.y) - 1)), scale * STAR_SPEED, scale))
