import pygame, math
import constants, sprite, transform, font, collision, images, label
from linear import *
from meta import *

COLLECTIBLE_PRIORITY = 8

ORE_RADIUS = 14

class Collectible(PriorityDrawable, collision.PartialCollider):
	def __init__(self, sprite, radius, speed, name, order = COLLECTIBLE_PRIORITY):
		PriorityDrawable.__init__(self, order)
		collision.PartialCollider.__init__(self, radius, 'collectible')
		
		self.sprite = sprite
		self.transform = self.sprite.transform
		self.speed = speed
		self.collectibleName = name
		
		self.label = label.StaticLabel(self.transform, Vector(0.0, self.radius + 5.0), font.make_epilepsy(18, self.collectibleName))
	
	def expired(self):
		return not self.transform.pos > constants.OBJECT_BOX[0] or not self.transform.pos < constants.OBJECT_BOX[1]
	
	def update(self, state):
		self.transform.rot = state.rotation.rot
		self.transform.move(Vector.fromAM(state.rotation.rot - 90, self.speed * state.keyboard.delta))
		
		self.label.set_string(self.collectibleName)
		self.label.update(state)
		
		self.sprite.update(state)
	
	def draw(self, state):
		self.sprite.draw(state)
		self.label.draw(state)

class CollectibleFactory(Manager):
	def spawn_ore(self, state, material, pos = None, rot = 0):
		if pos == None:
			Vector(0.0, 0.0)
		
		form = transform.Transform(pos, rot)
		spr = None
		
		if material != 'QUARKSLAG':
			spr = sprite.Sprite(images.get('media/ores/' + constants.NAMES[material] + '.png'), form)
		elif material == 'QUARKSLAG':
			spr = sprite.AniSprite(images.get('media/ores/' + constants.NAMES[material] + '.png'), form, 2, 2, constants.EPILEPSY_FACTOR, True)
		
		state.add_collidable(Collectible(spr, ORE_RADIUS, 100.0, material + ' ORE'))
