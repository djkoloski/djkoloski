import pygame, random

class GameObject(object):
	def expired(self):
		return False
	
	def update(self, state):
		pass

class Drawable(object):
	def draw(self, state):
		pass
	
	def priority(self):
		return 0
	
	def __lt__(self, other):
		return self.priority() < other.priority()

class Manager(GameObject):
	def reset(self):
		pass

class PriorityDrawable(Drawable):
	def __init__(self, order):
		self.order = order
	
	def priority(self):
		return self.order

class UpdateRenderState(object):
	def begin_state(self):
		pass
	
	def update(self):
		pass
	
	def draw(self):
		pass
	
	def end_state(self):
		return None

class MainLoop(object):
	def __init__(self, data, state):
		self.data = data
		self.state = state
	
	def main(self):
		self.state.begin_state()
		
		while True:
			self.data.update()
			
			if self.data.quit:
				break
			
			if self.state.update():
				self.state.draw()
				pygame.display.flip()
			else:
				temp = self.state.end_state()
				self.state = temp
				if self.state == None:
					break
				self.state.begin_state()

class orange(object):
	def __init__(self, l):
		self.l, self.i = l, 0
		self.o = None
	
	def __iter__(self):
		return self
	
	def __next__(self):
		return self.next()
	
	def next(self):
		if self.i >= len(self.l):
			raise StopIteration()
		if self.o == self.l[self.i]:
			self.i += 1
		if self.i >= len(self.l):
			raise StopIteration()
		self.o = self.l[self.i]
		return self.o

def gcd(a, b):
	while b:
		a, b = b, a % b
	return a

def lcm(a, b):
	return a * b // gcd(a, b)

def prandom(a, b):
	return a * ((1.0 - b) + random.random() * b)
