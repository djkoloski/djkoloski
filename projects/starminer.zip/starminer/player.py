import pygame, math
import constants, sprite, transform, collision, font, images, label
from linear import *
from meta import *

PLAYER_PRIORITY = 8

PLAYER_DEFAULT_SPEED = 500
PLAYER_DEFAULT_TURN_SPEED = 220
PLAYER_DEFAULT_ACCELERATION = 300
PLAYER_MAX_UP_DEVIATION = 75
PLAYER_FLAME_ANIM_TIME = 0.05
PLAYER_RADIUS = 14
PLAYER_HEALTH = 200.0

class Player(PriorityDrawable, collision.PartialCollider):
	def __init__(self):
		self.transform = transform.Transform(constants.RESOLUTION / 2.0)
		
		PriorityDrawable.__init__(self, PLAYER_PRIORITY)
		collision.PartialCollider.__init__(self, PLAYER_RADIUS, 'player')
		
		self.ship_sprite = sprite.AniSprite(images.get('media/player_ship.png'), self.transform, 4, 4, 40.0, True)
		self.max_health = PLAYER_HEALTH
		self.health = PLAYER_HEALTH
		self.healthtext = label.FractionLabel(self.transform, Vector(0.0, self.radius + 30.0), self.health, self.max_health, font.make_text(13, (0, 148, 0)), label.make_bar(100, 5, (0, 148, 0)))
		
		self.move_speed = PLAYER_DEFAULT_SPEED
		self.acceleration = PLAYER_DEFAULT_ACCELERATION
		self.turn_speed = PLAYER_DEFAULT_TURN_SPEED
	
	def move_relative(self, up, delta):
		move = math.sin(math.radians(up - self.transform.rot)) * self.move_speed * delta
		self.transform.move(Vector.fromAM(up, move))
		
		self.fixup_position()
	
	def fixup_position(self):
		self.transform.pos = vclamp(self.transform.pos, Vector(0.0, 0.0), constants.RESOLUTION)
	
	def turn_right(self, delta, up):
		self.transform.rotate(-self.turn_speed * delta)
		self.fixup_rotation(up)
	
	def turn_left(self, delta, up):
		self.transform.rotate(self.turn_speed * delta)
		self.fixup_rotation(up)
	
	def fixup_rotation(self, up):
		through = up - self.transform.rot
		
		if through < -180:
			through += 360
		if through > 180:
			through -= 360
		
		if math.fabs(through) > PLAYER_MAX_UP_DEVIATION:
			if through > 0:
				self.transform.rot = up - PLAYER_MAX_UP_DEVIATION
			else:
				self.transform.rot = up + PLAYER_MAX_UP_DEVIATION
	
	def move_vertical(self, delta, up, move):
		through = up - self.transform.rot
		
		if through < -180:
			through += 360
		if through > 180:
			through -= 360
		
		self.transform.move(Vector.fromAM(up + 90, move))
		
		self.fixup_position()
	
	def move_up(self, delta, up):
		self.move_vertical(delta, up, self.acceleration * delta)
	
	def move_down(self, delta, up):
		self.move_vertical(delta, up, -self.acceleration * delta)
	
	def get_coin(self):
		self.coins += 1
	
	def reset(self):
		self.health = self.max_health
		self.transform.pos = constants.RESOLUTION / 2.0
		self.transform.rot = 0
	
	def update(self, state):
		if state.keyboard.keys['right'].bool:
			self.turn_right(state.keyboard.delta, state.rotation.rot)
		
		if state.keyboard.keys['left'].bool:
			self.turn_left(state.keyboard.delta, state.rotation.rot)
		
		if state.keyboard.keys['up'].bool:
			self.move_up(state.keyboard.delta, state.rotation.rot)
		
		if state.keyboard.keys['down'].bool:
			self.move_down(state.keyboard.delta, state.rotation.rot)
		
		self.move_relative(state.rotation.rot, state.keyboard.delta)
		
		self.ship_sprite.update(state)
		self.healthtext.set_value(self.health)
		self.healthtext.update(state)
		
		self.fixup_rotation(state.rotation.rot)
	
	def draw(self, state):
		self.ship_sprite.draw(state)
		self.healthtext.draw(state)
