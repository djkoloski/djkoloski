import pygame, math, random
import constants, sprite, transform, font, collision, images, label
from linear import *
from meta import *

BREAKABLE_PRIORITY = 6
ASTEROID_RADIUS = 64

class Breakable(PriorityDrawable, collision.PartialCollider):
	def __init__(self, sprite, radius, health, speed, name, order = BREAKABLE_PRIORITY):
		PriorityDrawable.__init__(self, order)
		collision.PartialCollider.__init__(self, radius, 'breakable')
		
		self.sprite = sprite
		self.transform = self.sprite.transform
		self.max_health = health
		self.health = health
		self.speed = speed
		self.breakableName = name
		
		self.status = label.FractionLabel(self.transform, Vector(0.0, self.radius + 5.0), self.health, self.max_health, font.make_text(18, (0, 148, 0)), label.make_bar(200, 5, (0, 148, 0)))
	
	def expired(self):
		return not self.transform.pos > constants.OBJECT_BOX[0] or not self.transform.pos < constants.OBJECT_BOX[1]
	
	def update(self, state):
		self.transform.rot = state.rotation.rot
		self.transform.move(Vector.fromAM(state.rotation.rot - 90, self.speed * state.keyboard.delta))
		
		self.status.set_value(self.health)
		self.status.update(state)
		
		self.sprite.update(state)
	
	def draw(self, state):
		self.sprite.draw(state)
		if self.health >= 0.0:
			self.status.draw(state)

class BreakableFactory(Manager):
	def __init__(self):
		self.pause = 2.0
		self.time = 2.0
	
	def spawn_asteroid(self, state, material, pos = None, rot = 0):
		if pos == None:
			pos = Vector(0.0, 0.0)
		
		form = transform.Transform(pos, rot)
		spr = None
		
		if material != 'QUARKSLAG':
			spr = sprite.Sprite(images.get('media/asteroids/' + constants.NAMES[material] + '.png'), form)
		elif material == 'QUARKSLAG':
			spr = sprite.AniSprite(images.get('media/asteroids/' + constants.NAMES[material] + '.png'), form, 2, 2, constants.EPILEPSY_FACTOR, True)
		
		state.add_collidable(Breakable(spr, ASTEROID_RADIUS, 30.0, 250.0, material + ' ASTEROID'))
	
	def update(self, state):
		self.time -= state.keyboard.delta
		if self.time <= 0.0:
			self.spawn_asteroid(state, random.choice(constants.MATERIALS), constants.RESOLUTION / 2.0 + Vector.fromAM(state.rotation.rot + 90 + random.randint(-20, 20), 640))
			self.time = 2.0
