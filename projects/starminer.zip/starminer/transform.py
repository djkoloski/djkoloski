import math, copy
import pygame
import constants
from linear import *

class SurfCache(object):
	def __init__(self, form):
		self.surf = None
		self.rot = form.rot
		self.scale = form.scale
		self.offset = Vector(0.0, 0.0)
	
	def usable(self, form):
		return self.surf != None and fcmp(self.rot, form.rot) and self.scale == form.scale

class Transform(object):
	def __init__(self, pos = None, rot = 0.0, scale = None, center = None, smooth = False):
		if pos == None:
			pos = Vector(0.0, 0.0)
		if scale == None:
			scale = Vector(1.0, 1.0)
		if center == None:
			center = Vector(0.5, 0.5)
		self.center = center
		self.pos = pos
		self.rot = rot
		self.scale = scale
		self.smooth = smooth
	
	def move(self, v):
		self.pos += v
	
	def rotate(self, dr):
		self.rot += dr
		if self.rot < 0.0:
			self.rot += 360.0
		self.rot %= 360.0
	
	def cacheRender(self, source, target, surfcache):
		s = abs(self.scale)
		width = int(source.get_rect().width * s.x)
		height = int(source.get_rect().height * s.y)
		
		surf = None
		cached = surfcache.usable(self)
		
		if cached:
			surf = surfcache.surf
		else:
			surf = source
		
		if not cached:
			if self.scale.x < 0.0 or self.scale.y < 0.0:
				surf = pygame.transform.flip(source, self.scale.x < 0.0, self.scale.y < 0.0)
			if not fcmp(s.x, 1.0) or not fcmp(s.y, 1.0):
				if self.smooth:
					surf = pygame.transform.smoothscale(surf, (width, height))
				else:
					surf = pygame.transform.scale(surf, (width, height))
		
		loc = Vector(self.pos.x, self.pos.y)
		
		if not cached:
			ll = Vector(0.0, 0.0)
			nc = (self.center * Vector(width, height) * s)
			if not fcmp(self.rot, 0.0):
				r = Vector.fromAM(self.rot, height)
				surf = pygame.transform.rotate(surf, self.rot)
				
				if self.rot >= 0.0 and self.rot < 90.0:
					ll.x = r.y
				elif self.rot >= 90.0 and self.rot < 180.0:
					ll.x = surf.get_rect().width
					ll.y = -r.x
				elif self.rot >= 180.0 and self.rot < 270.0:
					ll.x = surf.get_rect().width + r.y
					ll.y = surf.get_rect().height
				else:
					ll.y = surf.get_rect().height - r.x
				nc.turn(self.rot)
			loc -= ll + nc
			surfcache.offset = ll + nc
		
		if cached:
			loc -= surfcache.offset
		
		if loc.x >= -surf.get_width() and loc.x <= constants.RESOLUTION.x and loc.y >= -surf.get_height() and loc.y <= constants.RESOLUTION.y:
			target.blit(surf, surf.get_rect().move(loc.x, target.get_rect().height - surf.get_rect().height - loc.y))
		
		if not cached:
			surfcache.surf = surf
			surfcache.rot = self.rot
			surfcache.scale = self.scale
			surfcache.offset = ll + nc
	
	def render(self, source, target):
		s = abs(self.scale)
		width = int(source.get_rect().width * s.x)
		height = int(source.get_rect().height * s.y)
		
		surf = source
		if self.scale.x < 0.0 or self.scale.y < 0.0:
			surf = pygame.transform.flip(source, self.scale.x < 0.0, self.scale.y < 0.0)
		if not fcmp(s.x, 1.0) or not fcmp(s.y, 1.0):
			if self.smooth:
				surf = pygame.transform.smoothscale(surf, (width, height))
			else:
				surf = pygame.transform.scale(surf, (width, height))
		
		ll = Vector(0.0, 0.0)
		nc = (self.center * Vector(width, height) * s)
		if not fcmp(self.rot, 0.0):
			r = Vector.fromAM(self.rot, height)
			surf = pygame.transform.rotate(surf, self.rot)
			
			if self.rot >= 0.0 and self.rot < 90.0:
				ll.x = r.y
			elif self.rot >= 90.0 and self.rot < 180.0:
				ll.x = surf.get_rect().width
				ll.y = -r.x
			elif self.rot >= 180.0 and self.rot < 270.0:
				ll.x = surf.get_rect().width + r.y
				ll.y = surf.get_rect().height
			else:
				ll.y = surf.get_rect().height - r.x
			nc.turn(self.rot)
		
		loc = self.pos - ll - nc
		
		if loc.x >= -surf.get_width() and loc.x <= constants.RESOLUTION.x and loc.y >= -surf.get_height() and loc.y <= constants.RESOLUTION.y:
			target.blit(surf, surf.get_rect().move(loc.x, target.get_rect().height - surf.get_rect().height - loc.y))
	
	def copy(self):
		return copy.deepcopy(self)
