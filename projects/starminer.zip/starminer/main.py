import pygame, sys, math, random
import keyboard, images, sprite, transform, savedata, font, states
import constants, menustate, gamestate, finishstate
from linear import *
from meta import *

def main():
	pygame.init()
	screen = pygame.display.set_mode((int(constants.RESOLUTION.x), int(constants.RESOLUTION.y)))
	pygame.display.set_caption('STARMINER')
	pygame.display.set_icon(images.get('media/icon.png'))
	
	data = savedata.Data(screen)
	
	states.make('menu', menustate.MenuState(data))
	states.make('game', gamestate.GameState(data))
	states.make('finishgame', finishstate.FinishState(data))
	
	main_loop = MainLoop(data, states.get('menu'))
	main_loop.main()

main()
