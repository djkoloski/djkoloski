import pygame
import constants, keyboard, font

SHIP_INITIAL_HEALTH = 200.0
SHIP_WEAPON_DEFAULT_BULLET = 'BULLET'
SHIP_WEAPON_INITIAL_SPEED = 0.5

IRON_PRICE = 3
SILVER_PRICE = 5
GOLD_PRICE = 9
REDMATTER_PRICE = 100
BLUETONIUM_PRICE = 250
VIOLITE_PRICE = 500
QUARKSLAG_PRICE = 1000

class ShipChamber(object):
	def __init__(self, capacity = 0):
		self.itemType = None
		self.capacity = capacity
		self.level = 0
	
	def empty(self):
		self.itemType = None
		amount = self.level
		self.level = 0
		return amount
	
	def can_collect(self, itemType, amount):
		if (self.itemType == None or self.itemType == itemType) and self.level < self.capacity:
			return True
		return False
	
	def collect(self, itemType, amount):
		if self.itemType == None:
			self.itemType = itemType
		if amount > self.capacity - self.level:
			amount -= self.capacity - self.level
			self.level = self.capacity
		else:
			self.level += amount
			amount = 0
		return amount

class ShipWeapon(object):
	def __init__(self, bullet = None, speed = None):
		if bullet == None:
			bullet = SHIP_WEAPON_DEFAULT_BULLET
		if speed == None:
			speed = SHIP_WEAPON_INITIAL_SPEED
		
		self.bullet = bullet
		self.speed = speed

class Ship(object):
	def __init__(self):
		self.chambers = []
		self.max_health = SHIP_INITIAL_HEALTH
		self.health = self.max_health
		self.weapon = ShipWeapon()
		self.onboard = {'IRON': 0, 'SILVER': 0, 'GOLD': 0}
	
	def add_chamber(self, chamber):
		self.chambers.append(chamber)
	
	def collect(self, itemType, amount):
		if itemType == 'IRON' or itemType == 'SILVER' or itemType == 'GOLD':
			self.onboard[itemType] += amount
			return 0
		else:
			for chamber in self.chambers:
				if chamber.can_collect(itemType, amount):
					amount = chamber.collect(itemType, amount)
				if amount == 0:
					break
			return amount
class Inventory(object):
	def __init__(self):
		self.resources = {'IRON': 0, 'SILVER': 0, 'GOLD': 0, 'REDMATTER': 0, 'BLUETONIUM': 0, 'VIOLITE': 0, 'QUARKSLAG': 0}
		self.money = 0

class Data(object):
	def __init__(self, screen):
		# equipment
		self.quit = False
		self.screen = screen
		self.keyboard = keyboard.Keyboard()
		self.map_keys()
		self.fonts = font.FontManager()
		self.load_fonts()
		
		# game data
		self.inventory = Inventory()
		self.prices = {'IRON': IRON_PRICE, 'SILVER': SILVER_PRICE, 'GOLD': GOLD_PRICE, 'REDMATTER': REDMATTER_PRICE, 'BLUETONIUM': BLUETONIUM_PRICE, 'VIOLITE': VIOLITE_PRICE, 'QUARKSLAG': QUARKSLAG_PRICE}
		
		self.ship = Ship()
		self.ship.add_chamber(ShipChamber(5))
	
	def map_keys(self):
		self.keyboard.map_key(pygame.K_ESCAPE, 'quit')
	
	def load_fonts(self):
		self.fonts.load_font('minecraftia', 'media/minecraftia.ttf')
	
	def collect_resources(self):
		for resource, amount in self.ship.onboard.items():
			self.inventory.resources[resource] += amount
		
		for chamber in self.ship.chambers:
			if chamber.itemType != None:
				self.inventory.resources[chamber.itemType] += chamber.empty()
	
	def sell_resources(self):
		for resource in self.inventory.resources.keys():
			self.sell_resource(resource)
	
	def sell_resource(self, name):
		amount = self.inventory.resources[name]
		self.inventory.resources[name] = 0
		self.inventory.money += amount * self.prices[name]
	
	def update(self):
		self.keyboard.poll()
		
		if self.keyboard.keys['quit'].down:
			self.quit = True
