import pygame, math
import constants, sprite, transform, font, collision, images
from linear import *
from meta import *

PROJECTILE_PRIORITY = 10

BULLET_DAMAGE = 10.0
BULLET_RADIUS = 8.5

class Projectile(PriorityDrawable, collision.PartialCollider):
	def __init__(self, sprite, radius, damage, speed, transform = None, order = PROJECTILE_PRIORITY):
		self.sprite = sprite
		if transform == None:
			self.transform = self.sprite.transform
		else:
			self.transform = transform
		self.damage = damage
		self.speed = speed
		
		PriorityDrawable.__init__(self, order)
		collision.PartialCollider.__init__(self, radius, 'projectile')
	
	def expired(self):
		return not self.transform.pos > constants.OBJECT_BOX[0] or not self.transform.pos < constants.OBJECT_BOX[1]
	
	def update(self, state):
		self.transform.move(Vector.fromAM(self.transform.rot + 90, self.speed * state.keyboard.delta))
		
		self.sprite.update(state)
	
	def draw(self, state):
		self.sprite.draw(state)

class ProjectileFactory(Manager):
	def spawn_player_bullets(self, state):
		form = state.player.transform.copy()
		state.add_collidable(Projectile(sprite.AniSprite(images.get('media/bullet.png'), form, 2, 2, constants.EPILEPSY_FACTOR, True), BULLET_RADIUS, BULLET_DAMAGE, 300.0))
