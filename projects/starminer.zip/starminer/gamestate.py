import pygame, random, math, bisect
import sprite, transform
import constants, keyboard, images, states, font, rotation, player, collision, breakable, projectile, collectible, passive, savedata, gui, finishstate
from linear import *
from meta import *

def game_main(state):
	state.update()
	state.draw()
	
	return state.execute

COMPASS_PRIORITY = 2
TIME_PER_RUN = 120.0
STAR_COUNT = 50

def damage_breakable(projectile, breakable, state):
	state.remove_object(projectile)
	breakable.health -= projectile.damage
	if breakable.health <= 0.0:
		state.remove_object(breakable)
		
		name = breakable.breakableName.split(' ', 1)
		material = name[0]
		obj = name[1]
		
		if obj == 'ASTEROID':
			state.collectibles.spawn_ore(state, material, breakable.transform.pos)

def damage_player(player, breakable, state):
	state.remove_object(breakable)
	player.health = max(0.0, player.health - breakable.health)

def get_collectible(player, collectible, state):
	get = False
	
	name = collectible.collectibleName.split(' ', 1)
	material = name[0]
	obj = name[1]
	
	if obj == 'ORE':
		get = (state.data.ship.collect(material, 1) != 1)
	
	if get:
		state.remove_object(collectible)

class GameState(UpdateRenderState):
	def __init__(self, data):
		self.data = data
		
		self.execute = True
		self.timer = 0.0
		
		self.screen = data.screen
		self.keyboard = data.keyboard
		self.map_keys()
		self.fonts = data.fonts
		
		self.objects = []
		self.managers = []
		
		self.collision = self.add_manager(collision.CollisionManager())
		self.add_contracts()
		self.breakables = self.add_manager(breakable.BreakableFactory())
		self.collectibles = self.add_manager(collectible.CollectibleFactory())
		self.passives = self.add_manager(passive.PassiveFactory())
		self.projectiles = self.add_manager(projectile.ProjectileFactory())
		self.rotation = self.add_manager(rotation.RotateManager())
		
		self.gui = None
		self.player = None
		self.compass = None
		
		self.clock = pygame.time.Clock()
	
	def map_keys(self):
		self.keyboard.map_key(pygame.K_p, 'pause')
		
		jettison_keys = [pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7, pygame.K_8, pygame.K_9, pygame.K_0]
		
		for i, k in enumerate(jettison_keys):
			self.keyboard.map_key(k, 'jettison_' + str(i))
		
		self.keyboard.map_key(pygame.K_SPACE, 'fire')
		self.keyboard.map_key(pygame.K_RIGHT, 'right')
		self.keyboard.map_key(pygame.K_UP, 'up')
		self.keyboard.map_key(pygame.K_LEFT, 'left')
		self.keyboard.map_key(pygame.K_DOWN, 'down')
	
	def unmap_keys(self):
		self.keyboard.unmap_key('pause')
		
		for i in xrange(10):
			self.keyboard.unmap_key('jettison_' + str(i))
		
		self.keyboard.unmap_key('fire')
		self.keyboard.unmap_key('right')
		self.keyboard.unmap_key('up')
		self.keyboard.unmap_key('left')
		self.keyboard.unmap_key('down')
	
	def add_contracts(self):
		self.collision.add_contract(collision.CollisionContract('projectile', 'breakable', damage_breakable))
		self.collision.add_contract(collision.CollisionContract('player', 'collectible', get_collectible))
		self.collision.add_contract(collision.CollisionContract('player', 'breakable', damage_player))
	
	def add_manager(self, obj):
		self.managers.append(obj)
		return obj
	
	def add_object(self, obj):
		bisect.insort(self.objects, obj)
		return obj
	
	def add_collidable(self, obj):
		self.collision.add_object(obj)
		return self.add_object(obj)
	
	def remove_object(self, obj):
		if isinstance(obj, collision.Collidable):
			self.collision.remove_object(obj)
		if obj in self.objects:
			self.objects.remove(obj)
	
	def clear_objects(self):
		self.objects = []
	
	def begin_state(self):
		self.execute = True
		self.timer = TIME_PER_RUN
		
		if self.gui == None:
			self.gui = gui.PlayingGUI(self)
		if self.player == None:
			self.player = player.Player()
		if self.compass == None:
			self.compass = sprite.Sprite(images.get('media/compass.png'), transform.Transform(constants.RESOLUTION / 2.0), COMPASS_PRIORITY)
		
		self.add_object(self.gui)
		self.add_collidable(self.player)
		self.add_object(self.compass)
		
		for i in xrange(STAR_COUNT):
			self.passives.spawn_star(self)
	
	def update(self):
		self.clock.tick()
		
		if self.keyboard.keys['pause'].down:
			self.execute = False
		
		self.timer -= self.keyboard.delta
		if self.timer <= 0.0:
			self.execute = False
		
		if self.player.health <= 0.0:
			self.execute = False
		
		# update managers
		for m in self.managers:
			m.update(self)
		
		# do stuff based on input
		if self.keyboard.keys['fire'].down:
			self.projectiles.spawn_player_bullets(self)
		
		for i in xrange(len(self.data.ship.chambers)):
			if self.keyboard.keys['jettison_' + str(i)].down:
				self.passives.spawn_neutralized_ore(self, self.player.transform.pos, self.data.ship.chambers[i].empty())
		
		# update objects
		for obj in orange(self.objects):
			obj.update(self)
			if obj.expired():
				self.remove_object(obj)
		
		return self.execute
	
	def draw(self):
		if not self.execute:
			return
		
		self.screen.fill((0, 0, 0))
		
		for obj in self.objects:
			obj.draw(self)
	
	def end_state(self):
		for man in self.managers:
			man.reset()
		
		self.data.ship.health = max(0.0, self.player.health)
		
		self.player.reset()
		self.clear_objects()
		
		return states.get('finishgame')
