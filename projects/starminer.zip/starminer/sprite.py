import pygame
import transform
from meta import *

class Sprite(PriorityDrawable, GameObject):
	def __init__(self, surf, form = None, order = 0):
		if form == None:
			form = transform.Transform()
		PriorityDrawable.__init__(self, order)
		self.surf = surf
		self.transform = form
		self.cache = None
		self.surfcache = transform.SurfCache(form)
	
	def update(self, state):
		pass
	
	def draw(self, state):
		self.transform.cacheRender(self.surf, state.screen, self.surfcache)

class AniSprite(PriorityDrawable, GameObject):
	def __init__(self, surf, form = None, frames_x = 1, frames_total = 1, fps = 1.0, loop = False, start = 0, order = 0):
		if form == None:
			form = transform.Transform()
		PriorityDrawable.__init__(self, order)
		self.surf = surf
		self.transform = form
		self.frames_x = frames_x
		self.frames_total = frames_total
		self.frame_width = surf.get_width() / frames_x
		self.frame_height = surf.get_height() / ((frames_total + frames_x - 1) / frames_x)
		self.time = 0.0
		self.pause = 1.0 / fps
		self.loop = loop
		self.cur_frame = start
		self.surfcaches = []
		for i in xrange(frames_total):
			self.surfcaches.append(transform.SurfCache(form))
	
	def advance(self, delta):
		if self.cur_frame != self.frames_total - 1 or self.loop:
			self.time -= delta
			while self.time < 0.0:
				self.time += self.pause
				self.cur_frame += 1
				if self.loop:
					self.cur_frame %= self.frames_total
	
	def update(self, state):
		if self.pause > 0.0:
			self.advance(state.keyboard.delta)
	
	def draw(self, state):
		cur_x = self.cur_frame % self.frames_x
		cur_y = self.cur_frame / self.frames_x
		self.transform.cacheRender(self.surf.subsurface(pygame.Rect(cur_x * self.frame_width, cur_y * self.frame_height, self.frame_width, self.frame_height)), state.screen, self.surfcaches[self.cur_frame])
