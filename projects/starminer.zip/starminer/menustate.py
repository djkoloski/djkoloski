import font, transform, constants, states
from meta import *

# TODO FINISH THIS

class MenuState(UpdateRenderState):
	def __init__(self, data):
		self.data = data
	
	def begin_state(self):
		pass
	
	def update(self):
		return False
	
	def draw(self):
		pass
	
	def end_state(self):
		return states.get('game')
