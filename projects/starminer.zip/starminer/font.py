import pygame, random, math
import sprite, transform
import constants, keyboard, player, collision, breakable
from linear import *
from meta import *

FONT_RENDER_SIZE = 800

def make_text(size, color, string = None, form = None, cache = False):
	if string == None:
		string = ''
	if form == None:
		form = transform.Transform()
	return Text('minecraftia', size, string, color, form, cache)

def make_flashing_text(size, colors, cps, string = None, form = None, cache = False):
	if string == None:
		string = ''
	if form == None:
		form = transform.Transform()
	return FlashingText('minecraftia', size, string, colors, cps, form, cache)


def make_epilepsy(size, string = None, form = None, cache = False):
	if string == None:
		string = ''
	if form == None:
		form = transform.Transform()
	return make_flashing_text(size, [constants.EPILEPSY_ORANGE, constants.EPILEPSY_BLUE], constants.EPILEPSY_FACTOR, string, form, cache)

def make_mutliline_text(size, color, string = None, form = None, cache = False):
	if string == None:
		string = ''
	if form == None:
		form = transform.Transform()
	pieces = string.split('\n')
	text = []
	for i, piece in enumerate(pieces):
		newform = form.copy()
		newform.center.y = len(pieces) / 2.0 - i
		text.append(make_text(size, color, piece, newform, cache))
	return text

def make_multiline_flashing_text(size, colors, cps, string = None, form = None, cache = False):
	if string == None:
		string = ''
	if form == None:
		form = transform.Transform()
	pieces = string.split('\n')
	text = []
	for i, piece in enumerate(pieces):
		newform = form.copy()
		newform.center.y = i + 1 - len(pieces) / 2.0
		text.append(make_flashing_text(size, colors, cps, piece, newform, cache))
	return text

def make_multiline_epilepsy(size, string = None, form = None, cache = False):
	if string == None:
		string = ''
	if form == None:
		form = transform.Transform()
	return make_multiline_flashing_text(size, [constants.EPILEPSY_ORANGE, constants.EPILEPSY_BLUE], constants.EPILEPSY_FACTOR, string, form, cache)

class Text(PriorityDrawable, GameObject):
	def __init__(self, font, size, string, color, transform, cache = False, order = 0):
		PriorityDrawable.__init__(self, order)
		self.font = font
		self.size = size
		self.string = string
		self.color = color
		self.transform = transform
		self.cacheFont = cache
		self.cache = None
	
	def set_string(self, string):
		if self.string != string:
			self.string = string
			self.cache = None
	
	def has_cache(self):
		return self.cache != None
	
	def get_cache(self):
		return self.cache
	
	def set_cache(self, cache):
		self.cache = cache
	
	def update(self, state):
		pass
	
	def draw(self, state):
		if not self.has_cache():
			self.set_cache(state.fonts.get_font(self.font).render(self.size, self.string, self.color, self.cacheFont))
		self.transform.render(self.get_cache(), state.screen)

class FlashingText(Text):
	def __init__(self, font, size, string, colors, cps, transform, cache = False, order = 0):
		Text.__init__(self, font, size, string, colors[0], transform, order)
		self.colors = colors
		self.pause = 1.0 / cps
		self.time = self.pause
		self.frame = 0
		self.cache = []
		for i in range(len(self.colors)):
			self.cache.append(None)
	
	def set_string(self, string):
		if self.string != string:
			self.string = string
			for i in range(len(self.cache)):
				self.cache[i] = None
	
	def has_cache(self):
		return self.cache[self.frame] != None
	
	def get_cache(self):
		return self.cache[self.frame]
	
	def set_cache(self, cache):
		self.cache[self.frame] = cache
	
	def update(self, state):
		self.time -= state.keyboard.delta
		while self.time < 0.0:
			self.time += self.pause
			self.frame += 1
			self.frame %= len(self.colors)
			self.color = self.colors[self.frame]

class Font(object):
	def __init__(self, font):
		self.font = font
		self.cache = {}
	
	def render(self, size, string, color, cache = False):
		surf = None
		have = (string, size) in self.cache.keys()
		if not have:
			surf = self.font.render(string, 1, (0, 0, 0)) if cache else self.font.render(string, 1, color)
			scale = float(size) / float(FONT_RENDER_SIZE)
			w = int(surf.get_width() * scale)
			h = int(surf.get_height() * scale)
			surf = pygame.transform.scale(surf, (w, h))
			if cache:
				self.cache[(string, size)] = surf
		else:
			surf = self.cache[(string, size)]
		
		if have or cache:
			surf = surf.copy()
			pxarray = pygame.PixelArray(surf)
			pxarray.replace((0, 0, 0), color)
		
		return surf

class FontManager(object):
	def __init__(self):
		self.fonts = {}
	
	def load_font(self, name, path):
		self.fonts[name] = Font(pygame.font.Font(path, FONT_RENDER_SIZE))
	
	def get_font(self, name):
		if name in self.fonts:
			return self.fonts[name]
		else:
			return None
