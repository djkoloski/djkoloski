import math

EPSILON = 0.0001

def fcmp(a, b, tolerance = EPSILON):
	return math.fabs(a - b) <= tolerance

def vmax(a, b):
	return Vector(max(a.x, b.x), max(a.y, b.y))

def vmin(a, b):
	return Vector(min(a.x, b.x), min(a.y, b.y))

def vclamp(a, b, c):
	return vmax(b, vmin(a, c))

class Vector(object):
	def __init__(self, x = 0.0, y = 0.0):
		self.x = float(x)
		self.y = float(y)
	
	def __gt__(self, other):
		return self.x > other.x and self.y > other.y
	
	def __lt__(self, other):
		return self.x < other.x and self.y < other.y
	
	def __eq__(self, other):
		if other == None:
			return False
		return fcmp(self.x, other.x) and fcmp(self.y, other.y)
	
	def __ne__(self, other):
		return not fcmp(self.x, other.x) or not fcmp(self.y, other.y)
	
	def __add__(self, other):
		return Vector(self.x + other.x, self.y + other.y)
	
	def __sub__(self, other):
		return Vector(self.x - other.x, self.y - other.y)
	
	def __mul__(self, other):
		if isinstance(other, (int, long, float)):
			return Vector(self.x * float(other), self.y * float(other))
		else:
			return Vector(self.x * other.x, self.y * other.y)
	
	def __div__(self, other):
		if isinstance(other, (int, long, float)):
			return Vector(self.x / float(other), self.y / float(other))
		else:
			return Vector(self.x / other.x, self.y / other.y)
	
	def __iadd__(self, other):
		self.x += other.x
		self.y += other.y
		return self
	
	def __isub__(self, other):
		self.x -= other.x
		self.y -= other.y
		return self
	
	def __imul__(self, other):
		if isinstance(other, (int, long, float)):
			self.x *= float(other)
			self.y *= float(other)
		else:
			self.x *= other.x
			self.y *= other.y
		return self
	
	def __idiv__(self, other):
		if isinstance(other, (int, long, float)):
			self.x /= float(other)
			self.y /= float(other)
		else:
			self.x /= other.x
			self.y /= other.y
	
	def __neg__(self):
		return Vector(-self.x, -self.y)
	
	def __pos__(self):
		return Vector(self.x, self.y)
	
	def __abs__(self):
		return Vector(math.fabs(self.x), math.fabs(self.y))
	
	def norm(self):
		return math.sqrt(self.x * self.x + self.y * self.y)
	
	def sqnorm(self):
		return self.x * self.x + self.y * self.y
	
	def normalize(self):
		n = self.norm()
		self.x /= n
		self.y /= n
	
	def is_normalized(self):
		return fcmp(self.sqnorm(), 1.0)
	
	def unit(self):
		n = self.norm()
		return Vector(self.x / n, self.y / n)
	
	def dot(self, other):
		return self.x * other.x + self.y * other.yset
	
	def angle(self, other):
		return math.degrees(math.acos(self.dot(other) / self.norm() / other.norm()))
	
	def parallel(self, other):
		return fcmp(self.dot(other), 1.0)
	
	def perpendicular(self, other):
		return fcmp(self.dot(other), 0.0)
	
	def dist(self, other):
		return math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)
	
	def cross(self):
		return Vector(-self.y, self.x)
	
	def rotate(self, angle):
		c = math.cos(math.radians(angle))
		s = math.sin(math.radians(angle))
		return Vector(self.x * c - self.y * s, self.x * s + self.y * c)
	
	def turn(self, angle):
		c = math.cos(math.radians(angle))
		s = math.sin(math.radians(angle))
		self.x, self.y = self.x * c - self.y * s, self.x * s + self.y * c
	
	@staticmethod
	def fromAM(angle = 0.0, magnitude = 1.0):
		return Vector(magnitude * math.cos(math.radians(angle)), magnitude * math.sin(math.radians(angle)))

class Matrix(object):
	def __init__(self, xx = 1.0, xy = 0.0, yx = 0.0, yy = 1.0):
		self.x = Vector(xx, xy)
		self.y = Vector(yx, yy)
	
	def __eq__(self, other):
		return self.x == other.x and self.y == other.y
	
	def __ne__(self, other):
		return self.x != other.x or self.y != other.y
	
	def __add__(self, other):
		return Matrix(self.x.x + other.x.x, self.x.y + other.x.y, self.y.x + other.y.x, self.y.y + other.y.y)
	
	def __sub__(self, other):
		return Matrix(self.x.x - other.x.x, self.x.y - other.x.y, self.y.x - other.y.x, self.y.y - other.y.y)
	
	def __mul__(self, other):
		if isinstance(other, (int, long, float)):
			return Matrix(self.x.x * float(other), self.x.y * float(other), self.y.x * float(other), self.y.y * float(other))
		else:
			if isinstance(other, Vector):
				return Vector(other.x * self.x.x + other.y * self.y.x, other.x * self.x.y + other.y * self.y.y)
			else:
				return Matrix(self.x.x * other.x.x + self.y.x * other.x.y, self.x.y * other.x.x + self.y.y * other.x.y, self.x.x * other.y.x + self.y.x * other.y.y, self.x.y * other.y.x + self.y.y * other.y.y)
	
	def __div__(self, other):
		if isinstance(other, (int, long, float)):
			return Matrix(self.x.x / float(other), self.x.y / float(other), self.y.x / float(other), self.y.y / float(other))
		else:
			return self.inverse() * other
	
	def __iadd__(self, other):
		self.x += other.x
		self.y += other.y
		return self
	
	def __isub__(self, other):
		self.x -= other.x
		self.y -= other.y
		return self
	
	def __imul__(self, other):
		if isinstance(other, (int, long, float)):
			self.x *= float(other)
			self.y *= float(other)
		else:
			self = self * other
		return self
	
	def __idiv__(self, other):
		if isinstance(other, (int, long, float)):
			self.x /= float(other)
			self.y /= float(other)
		else:
			self = self / other
		return self
	
	def __neg__(self):
		return Matrix(-self.x.x, -self.x.y, -self.y.x, -self.y.y)
	
	def __pos__(self):
		return Matrix(self.x.x, self.x.y, self.y.x, self.y.y)
	
	def rowMultiply(self, other):
		return Matrix(self.x.x * other.x.x, self.x.y * other.x.y, self.y.x * other.y.x, self.y.y * other.y.y)
	
	def rowDivide(self, other):
		return Matrix(self.x.x / other.x.x, self.x.y / other.x.y, self.y.x / other.y.x, self.y.y / other.y.y)
	
	def toRowMultiply(self, other):
		self.x, self.y = Vector(self.x.x * other.x.x, self.x.y * other.x.y), Vector(self.y.x * other.y.x, self.y.y * other.y.y)
	
	def toRowDivide(self, other):
		self.x, self.y = Vector(self.x.x / other.x.x, self.x.y / other.x.y), Vector(self.y.x / other.y.x, self.y.y / other.y.y)
	
	def determinant(self):
		return self.x.x * self.y.y - self.x.y * self.y.x
	
	def inverse(self):
		d = self.determinant()
		return Matrix(self.y.y / d, -self.x.y / d, -self.y.x / d, self.x.x / d)
	
	def orthoInverse(self):
		return self.transpose()
	
	def invert(self):
		d = self.determinant()
		self.x, self.y = Vector(self.y.y / d, -self.x.y / d), Vector(-self.y.x / d, self.x.x / d)
	
	def orthoInvert(self):
		self.flip()
	
	def transpose(self):
		return Matrix(self.x.x, self.y.x, self.x.y, self.y.y)
	
	def flip(self):
		self.x, self.y = Vector(self.x.x, self.y.x), Vector(self.x.y, self.y.y)
