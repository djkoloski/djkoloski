import pygame, random, math, bisect
import sprite, transform
import constants, keyboard, images, font, player, collision, breakable
from linear import *
from meta import *

MIN_ROTATE_PAUSE = 6
MAX_ROTATE_PAUSE = 14
MIN_ROTATE_SPEED = 10
MAX_ROTATE_SPEED = 60
INITIAL_ROTATE_PAUSE = 0

class RotateManager(Manager):
	def __init__(self):
		self.rot = 0.0
		self.target_rot = 0.0
		self.rotate_dir = 1
		self.rotate_speed = MIN_ROTATE_SPEED
		self.next_rotate = INITIAL_ROTATE_PAUSE
	
	def minimal_rotate(self, target):
		self.target_rot = target
		through = target - self.rot
		if through < 0:
			if through < -180:
				self.rotate_dir = 1
			else:
				self.rotate_dir = -1
		else:
			if through > 180:
				self.rotate_dir = -1
			else:
				self.rotate_dir = 1
	
	def maximal_rotate(self, target):
		self.minimal_rotate(target)
		self.rotate_dir = -self.rotate_dir
	
	def random_rotate(self):
		if random.randint(0, 1) == 0:
			self.minimal_rotate(random.randint(0, 360))
		else:
			self.maximal_rotate(random.randint(0, 360))
		
		rotate_diff = MAX_ROTATE_SPEED - self.rotate_speed
		self.rotate_speed += rotate_diff / 3.0
		
		self.next_rotate = float(random.randint(MIN_ROTATE_PAUSE, MAX_ROTATE_PAUSE))
	
	def reset(self):
		self.rot = 0.0
		self.target_rot = 0.0
		self.rotate_dir = 1
		self.rotate_speed = MIN_ROTATE_SPEED
		self.next_rotate = INITIAL_ROTATE_PAUSE
	
	def update(self, state):
		if self.rot != self.target_rot:
			through = self.target_rot - self.rot
			move = self.rotate_speed * state.keyboard.delta
			
			if through > 180:
				through -= 360
			if through < -180:
				through += 360
			
			if math.fabs(through) < move:
				self.rot = self.target_rot
			else:
				self.rot += self.rotate_dir * move
				if self.rot < 0:
					self.rot += 360
				self.rot %= 360
		else:
			self.next_rotate -= state.keyboard.delta
			if self.next_rotate <= 0:
				self.random_rotate()
		
		state.compass.transform.rot = self.rot
