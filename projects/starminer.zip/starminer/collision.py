import pygame, math, random
import constants, sprite, transform
from linear import *
from meta import *

class Collidable(GameObject):
	def get_position(self):
		return Vector(0.0, 0.0)
	
	def get_radius(self):
		return 0.0
	
	def get_name(self):
		return 0.0
	
	def is_colliding(self, other):
		return self.get_position().dist(other.get_position()) < (self.get_radius() + other.get_radius())

class PartialCollider(Collidable):
	def __init__(self, radius, name):
		self.radius = radius
		self.collisionName = name
	
	def get_position(self):
		return self.transform.pos
	
	def get_radius(self):
		return self.radius
	
	def get_name(self):
		return self.collisionName

class CollisionContract(object):
	def __init__(self, first, second, action):
		self.first = first
		self.second = second
		self.action = action
	
	def match(self, one, two):
		return one.get_name() == self.first and two.get_name() == self.second
	
	def act(self, one, two, data = None):
		if one.get_name() == self.first and two.get_name() == self.second:
			if data == None:
				self.action(one, two)
			else:
				self.action(one, two, data)

class CollisionCell(object):
	def __init__(self):
		self.objects = []
	
	def add_object(self, o):
		self.objects.append(o)
	
	def remove_object(self, o):
		self.objects.remove(o)

class CollisionManager(Manager):
	def __init__(self):
		self.objects = {}
		self.contracts = []
		self.firsts = {}
		self.seconds = {}
	
	def add_contract(self, con):
		self.contracts.append(con)
		
		if con.first in self.firsts:
			self.firsts[con.first].append(con.second)
		else:
			self.firsts[con.first] = [con.second]
		
		if con.second in self.seconds:
			self.seconds[con.second].append(con.first)
		else:
			self.seconds[con.second] = [con.first]
	
	def remove_contract(self, con):
		self.contracts.remove(con)
		
		self.firsts[con.first].remove(con.second)
		self.seconds[con.second].remove(con.first)
		
		if len(self.firsts[con.first]) == 0:
			self.firsts.remove(con.first)
		if len(self.seconds[con.second]) == 0:
			self.seconds.remove(con.second)
	
	def add_object(self, o):
		if not o.get_name() in self.objects:
			self.objects[o.get_name()] = []
		if not o in self.objects[o.get_name()]:
			self.objects[o.get_name()].append(o)
	
	def remove_object(self, o):
		if o.get_name() in self.objects:
			if o in self.objects[o.get_name()]:
				self.objects[o.get_name()].remove(o)
	
	def check_collisions(self, state):
		for f in self.firsts.keys():
			if f in self.objects:
				for o in self.objects[f]:
					for s in self.firsts[f]:
						if s in self.objects:
							for p in self.objects[s]:
								if o is p:
									continue
								if o.is_colliding(p):
									self.enact_contract(o, p, state)
	
	def enact_contract(self, o, p, state):
		for con in self.contracts:
			if con.match(o, p):
				con.act(o, p, state)
	
	def reset(self):
		self.objects = {}
	
	def update(self, state):
		self.check_collisions(state)
