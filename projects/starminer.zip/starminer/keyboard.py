import pygame

class Key(object):
	def __init__(self):
		self.bool = False
		self.down = False
		self.up = False
	
	def key_down(self):
		self.bool = True
		self.down = True
	
	def key_up(self):
		self.bool = False
		self.up = True
	
	def key_none(self):
		self.down = False
		self.up = False

class Keyboard(object):
	def __init__(self):
		self.keyEvents = dict()
		self.keys = dict()
		self.ticks = 0
		self.delta = 0.0
	
	def map_key(self, key, name):
		self.keyEvents[key] = name
		self.keys[name] = Key()
	
	def unmap_key(self, key):
		self.keys.pop(self.keyEvents[key])
		self.keyEvents.pop(key)
	
	def key_down(self, k):
		if k in self.keyEvents:
			self.keys[self.keyEvents[k]].key_down()
	
	def key_up(self, k):
		if k in self.keyEvents:
			self.keys[self.keyEvents[k]].key_up()
	
	def handle(self, event):
		if event.type == pygame.KEYDOWN:
			self.key_down(event.key)
		elif event.type == pygame.KEYUP:
			self.key_up(event.key)
	
	def poll(self):
		self.delta = (pygame.time.get_ticks() - self.ticks) / 1000.0
		for key, val in self.keys.iteritems():
			val.key_none()
		for event in pygame.event.get():
			self.handle(event)
		self.ticks = pygame.time.get_ticks()
