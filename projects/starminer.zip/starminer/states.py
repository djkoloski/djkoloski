CREATED_STATES = {}

def make(name, state):
	assert not name in CREATED_STATES.keys()
	CREATED_STATES[name] = state

def get(name):
	assert name in CREATED_STATES.keys()
	return CREATED_STATES[name]
