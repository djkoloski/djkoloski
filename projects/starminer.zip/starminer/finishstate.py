import font, transform, constants, states
from meta import *

END_LEVEL_PAUSE = 2.0

class FinishState(UpdateRenderState):
	def __init__(self, data):
		self.data = data
		self.success = True
		self.text = None
		self.game = None
		self.successtext = font.make_multiline_epilepsy(200, 'RUN\nCOMPLETE!', transform.Transform(constants.RESOLUTION / 2.0))
		self.failuretext = font.make_multiline_epilepsy(200, 'RUN\nFAILED', transform.Transform(constants.RESOLUTION / 2.0))
		self.timer = 0.0
	
	def begin_state(self):
		if self.game == None:
			self.game = states.get('game')
		self.timer = END_LEVEL_PAUSE
		if self.data.ship.health > 0.0:
			self.text = self.successtext
		else:
			self.text = self.failuretext
	
	def update(self):
		self.timer -= self.data.keyboard.delta
		for text in self.text:
			text.update(self.data)
		
		return self.timer > 0.0
	
	def draw(self):
		self.game.draw()
		for text in self.text:
			text.draw(self.data)
	
	def end_state(self):
		return states.get('menu')
