import pygame, math
import constants, sprite, transform, font, collision, images, label
from linear import *
from meta import *

GUI_PRIORITY = 4
CAPACITY_SCALE = 20.0

class PlayingGUI(PriorityDrawable, GameObject):
	def __init__(self, state):
		PriorityDrawable.__init__(self, GUI_PRIORITY)
		
		self.ironlabel = font.make_text(20, constants.COLORS['IRON'][0], 'I', transform.Transform(Vector(40, 728), 0, Vector(1.0, 1.0), Vector(1.0, 0.0)), True)
		self.irontext = font.make_text(20, constants.COLORS['IRON'][0], str(state.data.ship.onboard['IRON']), transform.Transform(Vector(60, 728), 0, Vector(1.0, 1.0), Vector(0.0, 0.0)))
		self.silverlabel = font.make_text(20, constants.COLORS['SILVER'][0], 'S', transform.Transform(Vector(40, 698), 0, Vector(1.0, 1.0), Vector(1.0, 0.0)), True)
		self.silvertext = font.make_text(20, constants.COLORS['SILVER'][0], str(state.data.ship.onboard['SILVER']), transform.Transform(Vector(60, 698), 0, Vector(1.0, 1.0), Vector(0.0, 0.0)))
		self.goldlabel = font.make_text(20, constants.COLORS['GOLD'][0], 'G', transform.Transform(Vector(40, 668), 0, Vector(1.0, 1.0), Vector(1.0, 0.0)), True)
		self.goldtext = font.make_text(20, constants.COLORS['GOLD'][0], str(state.data.ship.onboard['GOLD']), transform.Transform(Vector(60, 668), 0, Vector(1.0, 1.0), Vector(0.0, 0.0)))
		
		self.statusbars = []
		
		lower_left = Vector(20, 20)
		for chamber in state.data.ship.chambers:
			self.statusbars.append(label.FlashingFractionBar(transform.Transform(lower_left, 0, Vector(1.0, 1.0), Vector(0.0, 0.0)), chamber.level, chamber.capacity, constants.COLORS[chamber.itemType], constants.COLORS[None], Vector(10, chamber.capacity * CAPACITY_SCALE), constants.EPILEPSY_FACTOR, True))
			lower_left += Vector(20, 0)
		
		self.timertext = font.make_epilepsy(40, str(round(state.timer, 1)), transform.Transform(Vector(1004, 758), 0, Vector(1.0, 1.0), Vector(1.0, 1.0)))
		self.moneytext = font.make_epilepsy(40, str(int(state.data.inventory.money)) + ' M', transform.Transform(Vector(1004, 10), 0, Vector(1.0, 1.0), Vector(1.0, 0.0)))
		
		self.fpstext = font.make_epilepsy(20, str(round(state.clock.get_fps(), 1)) + ' FPS', transform.Transform(Vector(1004, 700), 0, Vector(1.0, 1.0), Vector(1.0, 1.0)))
	
	def update(self, state):
		for bar, chamber in zip(self.statusbars, state.data.ship.chambers):
			if bar.foregrounds != constants.COLORS[chamber.itemType]:
				bar.set_foregrounds(constants.COLORS[chamber.itemType])
			bar.set_value(chamber.level)
			bar.update(state)
		
		self.irontext.set_string(str(state.data.ship.onboard['IRON']))
		self.silvertext.set_string(str(state.data.ship.onboard['SILVER']))
		self.goldtext.set_string(str(state.data.ship.onboard['GOLD']))
		
		self.ironlabel.update(state)
		self.irontext.update(state)
		self.silverlabel.update(state)
		self.silvertext.update(state)
		self.goldlabel.update(state)
		self.goldtext.update(state)
		
		self.timertext.set_string(str(round(state.timer, 1)))
		self.timertext.update(state)
		
		self.moneytext.set_string(str(int(state.data.inventory.money)) + ' M')
		self.moneytext.update(state)
		
		self.fpstext.set_string(str(round(state.clock.get_fps(), 1)) + ' FPS')
		self.fpstext.update(state)
	
	def draw(self, state):
		for bar in self.statusbars:
			bar.draw(state)
		
		self.ironlabel.draw(state)
		self.irontext.draw(state)
		self.silverlabel.draw(state)
		self.silvertext.draw(state)
		self.goldlabel.draw(state)
		self.goldtext.draw(state)
		
		self.timertext.draw(state)
		self.moneytext.draw(state)
		
		self.fpstext.draw(state)
