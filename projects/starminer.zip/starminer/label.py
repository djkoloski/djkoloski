import pygame, math
import constants, sprite, transform, font, collision, images
from linear import *
from meta import *

def make_bar(size_x, size_y, foreground, background = None, orientation = False, current = 0.0, maximum = 0.0, form = None):
	if form == None:
		form = transform.Transform()
	if background == None:
		background = constants.COLOR_NONE
	return FractionBar(form, current, maximum, foreground, background, Vector(size_x, size_y), orientation)

def make_epileptic_bar(size_x, size_y, orientation = False, current = 0.0, maximum = 0.0, form = None):
	if form == None:
		form = transform.Transform()
	return FlashingFractionBar(form, current, maximum, [constants.EPILEPSY_ORANGE, constants.EPILEPSY_BLUE], [constants.EPILEPSY_BLUE, constants.EPILEPSY_ORANGE], Vector(size_x, size_y), constants.EPILEPSY_FACTOR)

class FractionBar(GameObject):
	def __init__(self, transform, current, maximum, foreground, background, size, orientation = False):
		self.transform = transform
		self.current = current
		self.maximum = maximum
		self.foreground = foreground
		self.background = background
		self.size = size
		self.orientation = orientation
	
	def set_maximum(self, value):
		self.maximum = value
	
	def set_value(self, value):
		self.current = value
	
	def update(self, state):
		pass
	
	def draw(self, state):
		part = float(self.current) / float(self.maximum)
		pos = self.transform.pos - self.size * self.transform.center
		
		width = None
		height = None
		fullpos = pos
		emptypos = fullpos
		
		if self.orientation:
			width = [self.size.x, self.size.x]
			height = [part * self.size.y, (1.0 - part) * self.size.y]
			fullpos = pos + Vector(0.0, height[0])
			emptypos = fullpos + Vector(0.0, height[1])
		else:
			width = [part * self.size.x, (1.0 - part) * self.size.x]
			height = [self.size.y, self.size.y]
			fullpos = pos + Vector(0.0, height[0])
			emptypos = fullpos + Vector(width[0], 0.0)
		
		if part > 0.0:
			pygame.draw.rect(state.screen, self.foreground, pygame.Rect(int(fullpos.x), state.screen.get_height() - int(fullpos.y), int(width[0]), int(height[0])))
		if part < 1.0:
			pygame.draw.rect(state.screen, self.background, pygame.Rect(int(emptypos.x), state.screen.get_height() - int(emptypos.y), int(width[1]), int(height[1])))

class FlashingFractionBar(FractionBar):
	def __init__(self, transform, current, maximum, foregrounds, backgrounds, size, cps, orientation = False):
		FractionBar.__init__(self, transform, current, maximum, foregrounds[0], backgrounds[0], size, orientation)
		self.foregrounds = foregrounds
		self.backgrounds = backgrounds
		self.pause = 1.0 / cps
		self.time = self.pause
		self.frame = 0
		self.repeat = lcm(len(foregrounds), len(backgrounds))
	
	def set_foregrounds(self, foregrounds):
		self.foregrounds = foregrounds
		self.repeat = lcm(len(self.foregrounds), len(self.backgrounds))
	
	def update(self, state):
		self.time -= state.keyboard.delta
		while self.time < 0.0:
			self.time += self.pause
			self.frame += 1
			self.frame %= self.repeat
			self.foreground = self.foregrounds[self.frame % len(self.foregrounds)]
			self.background = self.backgrounds[self.frame % len(self.backgrounds)]

class Label(GameObject):
	def __init__(self, transform, offset, text):
		self.watchTransform = transform
		self.offset = offset
		self.text = text
		
		self.text.transform.pos = self.watchTransform.pos + offset
		self.text.transform.rot = 0
		self.text.transform.center = Vector(0.5, 0.0)
	
	def set_string(self, string):
		self.text.set_string(string)
	
	def update(self, state):
		self.text.transform.pos = self.watchTransform.pos + self.offset
		self.text.update(state)
	
	def draw(self, state):
		self.text.draw(state)

class StaticLabel(Label):
	def __init__(self, transform, offset, text):
		text.cacheFont = True
		Label.__init__(self, transform, offset, text)

class FractionLabel(Label):
	def __init__(self, transform, offset, current, maximum, text, bar):
		text.cacheFont = True
		Label.__init__(self, transform, offset, text)
		self.current = current
		self.maximum = maximum
		self.bar = bar
		self.bar.set_maximum(self.maximum)
		self.bar.set_value(self.current)
		self.bar.transform.pos = self.watchTransform.pos + self.offset - Vector(0.0, self.bar.size.y)
	
	def set_value(self, value):
		self.current = value
		self.bar.set_value(value)
		
		Label.set_string(self, str(self.current) + '/' + str(self.maximum))
	
	def update(self, state):
		self.bar.transform.pos = self.watchTransform.pos + self.offset - Vector(0.0, self.bar.size.y)
		self.bar.update(state)
		Label.update(self, state)
	
	def draw(self, state):
		Label.draw(self, state)
		self.bar.draw(state)
