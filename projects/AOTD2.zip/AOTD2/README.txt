AOTD2 was my first highly successful game; by highly successful, I mean that it was well-liked by my colleagues
at school and spread amongst the student body like I could never have expected. The game is based off of an iPod
app called Tilt to Live, and was originally built as a test of my game engine's 2D capabilities. The original
game, AOTD, stood for Attack Of The Dots and was built for an online game design course in Multimedia Fusion II,
a WYSIWYG game maker. I felt unsatisfied with its performance, as MMF2 was inflexible and definitely not built
for a game such as AOTD. When I rewrote the entirety of the game using my game engine, AOTD2 finally fulfilled
what I truly wanted the game to become. The color schemes and artwork for AOTD2 went through several iterations
before reaching its final, current, state. The game originally used bitmapped fonts, but after I added font
support to my game engine, I switched over to rasterized vector fonts.

Here's how to play:

Main Menu:
	Click the play button to begin the game.
	Click the scores button to see the high score table and import/export scores.
	Click the settings button to change your name and modify the play settings.

Game:
	In-game, there are three or four totals, two on the left and one or two on the right. On the left are the
	missile and mine totals. When a missile or mine powerup is picked up, the totals will increase 2 (or 1 if
	Fewer Drops is on in the settings). On the right, in black is the kill count and in red is the score. If
	there are no multipliers, the kill count will be equal to the score, and a red number will not be drawn.
	The goal of the game is simple: kill the dots before they touch you. As soon as a dot touches you, you
	will be taken to the high score table. The only way to kill the dots is to use the powerups that spawn
	around the battlefield. To move your ship, use the mouse. There are a few different powerups:
		Missiles: shaped like your ship, but smaller. To fire missiles, press the 'f' key. As the missiles
		travel across the screen, they will kill all dots they touch. You can only use as many missiles as
		your missile count.
		Mines: shaped like purple 'x's, missiles create a small explosion whenever a dot touches them, then
		disappear. To drop mines, press the 'd' key.
		Bangs: Bang powerups have an exclamation point (!) on them. When picked up, the bang powerup is used
		immediately, but creates a large explosion, killing all dots it touches.
		Shield: Shields follow your ship around until they come in contact with a dot, exploding and allowing
		you to pick up another shield. Shields are single-use.
		Lasers (Shoops): Laser powerups are marked with a Shoop-da-Whoop face, and, when picked up, create a
		a laser beam between the place where the laser was picked up and the ship's current location. Any dot
		caught in the laser will be killed. Be careful though: you're not invincible with just a laser.
	The dots spawn in many different formations, in increasingly greater numbers. Remain cautious! When dots first
	spawn, they flash. During this time, they can be killed, but they will not kill you. They begin moving after a
	few flashes.
	To pause the game, press escape.

High Score:
	On the high score board, all of the different high scores are displayed, with the top three highlighted in
	gold, silver, and bronze. On the bottom left, the import button can be used to share scores with your friends.
	To get a score code, click the 'copy code' button to the left of a score, then paste it into a chat or IM.
	Your friend can copy the code with control-c, then click 'import'. If the code is valid, then the score will
	be added into their score board. If not, the import will fail. All codes have a required security code which
	enforces its authenticity.

Settings:
	In the settings, you can change your name and turn on and off score multipliers. Your total multiplier will be
	displayed at the bottom. To finish changing your name, just hit enter at the end.
	Multipliers:
		Faster Dots: Dots move slightly faster than usual.
		Faster Spawns: Waves of dots appear slightly faster than usual.
		More Dots per Wave: Waves of dots will have, on average, more dots than usual.
		Slower Powerups: Powerups will take slightly longer to spawn than usual.
		Fewer Drops: Missile and mine powerups will give only 1 apiece instead of 2.
		Harder Formations: Dots will tend to spawn in formations that make them more difficult to avoid.

That's all you need to know to play. Enjoy the game, share it with your friends, and compete for the highest score!

- David Koloski
